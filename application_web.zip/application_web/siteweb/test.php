
<!-- form simple à utiliser pour visualiser un élément dans la liste -->
<form action="visualisation.php" method="post">
    <input type="hidden" value="1" name="idcommande">
    <input type="submit" value="Voir Carte"></input>
</form>